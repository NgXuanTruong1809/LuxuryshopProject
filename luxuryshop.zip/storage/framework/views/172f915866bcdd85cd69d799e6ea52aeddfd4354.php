  <!DOCTYPE html>
  <html>

  <head>
      <title>Cửa hàng</title>
      <?php echo $__env->make('front-end.common.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <style>
          .shop__sidebar__categories .active {
              color: black;
          }

          .shop__sidebar__price .active {
              color: black;
          }
      </style>
  </head>

  <body>
      <?php echo $__env->make('front-end.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <section class="breadcrumb-option">
          <div class="container">
              <div class="row">
                  <div class="col-lg-12">
                      <div class="breadcrumb__text">
                          <h4>Cửa hàng</h4>
                          <div class="breadcrumb__links">
                              <a href="/">Trang chủ</a>
                              <img src="/images/right-arrow.png">
                              <span>Cửa hàng</span>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <section class="shop spad">
          <div class="container">
              <div class="row">
                  <div class="col-lg-3">
                      <div class="shop__sidebar">
                          <div class="shop__sidebar__search">
                              <form action="<?php echo e(url('shop-search')); ?>" method="get">
                                  <input type="text" placeholder="Tìm kiếm..." name="searchInput">
                                  <button type="submit"><img src="/images/search.png"></button>
                              </form>
                          </div>
                          <div class="shop__sidebar__accordion">
                              <div class="accordion" id="accordionExample">


                                  <div class="card-heading">
                                      <a href="/shop">Sản phẩm </a>
                                  </div>
                                  <div class="card">
                                      <div class="card-heading">
                                          <a data-toggle="collapse" data-target="#collapseOne">Danh mục
                                              <img src="/images/arrow-down.png"></a>
                                      </div>
                                      <div id="collapseOne" class="collapse show" data-parent="#accordionExample">
                                          <div class="card-body">
                                              <div class="shop__sidebar__categories">
                                                  <ul class="nice-scroll">
                                                      <li><a href="/shop-search?categoryid=-1&page=1" class="<?php if($currentCategoryId == null): ?> 'active' <?php endif; ?>"> Bỏ lọc</a></li>
                                                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      <li><a href="/shop-search?categoryid=<?php echo e($cate->id); ?>&page=1" class="<?php if($currentCategoryId == $cate->id): ?> <?php echo e('active'); ?> <?php endif; ?>"> <?php echo e($cate->name); ?></li>
                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                  </ul>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                                  <div class="card">
                                      <div class="card-heading">
                                          <a data-toggle="collapse" data-target="#collapseThree">Lọc giá sản phẩm
                                              <img src="/images/arrow-down.png"></a>
                                      </div>
                                      <div id="collapseThree" class="collapse show" data-parent="#accordionExample">
                                          <div class="card-body">
                                              <div class="shop__sidebar__price">
                                                  <ul>
                                                      <li><a class="<?php if($price==-1): ?> <?php echo e('active'); ?> <?php endif; ?>" href="/shop-search?priceBegin=-1">Bỏ lọc</a></li>
                                                      <li><a class="<?php if($price==0): ?> <?php echo e('active'); ?> <?php endif; ?>" href="/shop-search?priceBegin=0&priceEnd=100000&page=1">0đ - 100.000đ</a></li>
                                                      <li><a class="<?php if($price==100000): ?> <?php echo e('active'); ?> <?php endif; ?>" href="/shop-search?priceBegin=100000&priceEnd=500000&page=1">100.000đ - 500.000đ</a></li>
                                                      <li><a class="<?php if($price==500000): ?> <?php echo e('active'); ?> <?php endif; ?>" href="/shop-search?priceBegin=500000&priceEnd=1000000&page=1">500.000 - 1.000.000</a></li>
                                                      <li><a class="<?php if($price==1000000): ?> <?php echo e('active'); ?> <?php endif; ?>" href="/shop-search?priceBegin=1000000">1.000.000+</a></li>
                                                  </ul>
                                              </div>
                                          </div>
                                      </div>
                                  </div>

                                  <div class="card">
                                    <div class="card-heading">
                                        <a data-toggle="collapse" data-target="#collapseOne">Bộ sưu tập
                                        <img src="/images/arrow-down.png"></a>
                                    </div>
                                    <div id="collapseOne" class="collapse show" data-parent="#accordionExample">
                                        <div class="card-body">
                                            <div class="shop__sidebar__categories">
                                                <ul class="nice-scroll">
                                                	<li><a href="/shop-search?collectionid=-1&page=1" class="<?php if($currentCategoryId == null): ?> 'active' <?php endif; ?>"> Bỏ lọc</a></li>
	                                                <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="/shop-search?collectionid=<?php echo e($collec->id); ?>&page=1" class="<?php if($currentCategoryId == $collec->id): ?> <?php echo e('active'); ?> <?php endif; ?>"> <?php echo e($collec->name); ?></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
                                            </div>
                                        </div>
                                    </div>
                                   </div>

                                  <div class="card">
                                      <div class="card-heading">
                                          <a data-toggle="collapse" data-target="#collapseSix">Thẻ
                                              <img src="/images/arrow-down.png"></a>
                                      </div>
                                      <div id="collapseSix" class="collapse show" data-parent="#accordionExample">
                                          <div class="card-body">
                                              <div class="shop__sidebar__tags">
                                                  <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <a href="/shop-search?tag=<?php echo e($tag->name); ?>"><?php echo e($tag->name); ?></a>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </div>
                                          </div>
                                      </div>
                                  </div>

                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-lg-9">
                      <div class="shop__product__option">
                          <div class="row">
                              <div class="col-lg-6 col-md-6 col-sm-6">
                                  <div class="shop__product__option__left">
                                      <p>Hiển thị <?php echo e(count($products)); ?> / <?php echo e($size); ?> kết quả</p>
                                  </div>
                              </div>
                              <div class="col-lg-6 col-md-6 col-sm-6">
                                  <div class="shop__product__option__right">


                                      <p>Sắp xếp giá:</p>
                                      <select onchange="location = this.value;" style="width:20px;">
                                          <option></option>
                                          <option value="/shop-search?sort=asc&page=1">Thấp đến cao</option>
                                          <option value="/shop-search?sort=desc&page=1">Cao đến thấp</option>
                                      </select>

                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="row">
                          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="col-lg-4 col-md-6 col-sm-6">
                              <div class="product__item">

                                  <div class="product__item__pic set-bg" data-setbg="/file/upload/<?php echo e($product->url_avatar); ?>">
                                      <span class="label">Hot</span>
                                      <ul class="product__hover">
                                          <li><a href=""><img src="/images/redheart.png" alt=""><span>Yêu thích</span></a></li>
                                          <li><a><img src="/images/compare.png" alt=""><span>So sánh</span></a></li>
                                          <li><a href="/shop-details/<?php echo e($product->seo); ?>"><img src="/images/search.png" alt=""><span>Chi tiết</span></a></li>
                                      </ul>
                                  </div>
                                  <div class="product__item__text">
                                      <h6><?php echo e($product->title); ?></h6>
                                      <a href="javascript:void(0)" class="add-cart" onclick="cart.choose_product_to_cart(<?php echo e($product->id); ?>, 1)">+ Thêm vào giỏ hàng</a>


                                      <div class="rating d-flex">
                                          <img width="15px" src="/images/yellow-star.png">
                                          <img width="15px" src="/images/yellow-star.png">
                                          <img width="15px" src="/images/yellow-star.png">
                                          <img width="15px" src="/images/yellow-star.png">
                                          <img width="15px" src="/images/yellow-star.png">
                                      </div>
                                      <h5>
                                          <?php echo e(number_format($product->price)); ?>

                                          <span style="text-decoration:line-through; font-size:14px; color:grey;">
                                              <?php echo e(number_format($product->price_old)); ?>

                                          </span>
                                      </h5>
                                      <div class="product__color__select">
                                          <label class="silver" for="pc-1">
                                              <input type="radio" id="pc-1">
                                          </label>
                                          <label class="active grey" for="pc-2">
                                              <input type="radio" id="pc-2">
                                          </label>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>

                      <div class="row">
                          <div class="col-lg-12">

                              <div class="product__pagination">
                                  <?php if($totalPage == 1): ?>
                                  <a href="/shop-search?page=1" class="active"><button type="button" class="btn btn-outline-dark">1</button></a>
                                  <?php else: ?>
                                  <?php if($currentPage > 1 && $currentPage <= $totalPage): ?> <a href="/shop-search?page=<?php echo e($currentPage - 1); ?>"><button type="button" class="btn btn-outline-dark">&laquo;</button></a>
                                      <?php endif; ?>

                                    <?php for($i = 1; $i <= $totalPage; $i++): ?> <?php if($i==$currentPage): ?> <a href="/shop-search?page=<?php echo e($i); ?>" class="active"><button type="button" class="btn btn-outline-dark"><?php echo e($i); ?></button></a>
                                          <?php endif; ?>
                                          <?php if($i != $currentPage): ?>
                                          <a href="/shop-search?page=<?php echo e($i); ?>"><button type="button" class="btn btn-outline-dark"><?php echo e($i); ?></button></a>
                                          <?php endif; ?>
                                    <?php endfor; ?>
                                          <?php if($currentPage >= 1 && $currentPage < $totalPage): ?> <a href="/shop-search?page=<?php echo e($currentPage + 1); ?>"><button type="button" class="btn btn-outline-dark">&raquo;</button></a>
                                              <?php endif; ?>
                                    <?php endif; ?>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <?php echo $__env->make('front-end.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <script type="text/javascript" src="<?php echo e(asset('js/page.js')); ?>"></script>
      <?php echo $__env->make('front-end.common.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>

  </html>
<?php /**PATH D:\taiLieuHocTap\HK-7\Open-source software\luxury_shop\luxuryshop\resources\views/front-end/shop.blade.php ENDPATH**/ ?>